
import { useState } from "react";

export default function Home() {
  const [word, setWord] = useState("");
  const [imageOptions, setImageOptions] = useState([]);
  const [sentenceImages, setSentenceImages] = useState([]);

  const handleSearch = () => {
    const placeholderImages = [
      "https://via.placeholder.com/100?text=Option+1",
      "https://via.placeholder.com/100?text=Option+2",
      "https://via.placeholder.com/100?text=Option+3",
      "https://via.placeholder.com/100?text=Option+4"
    ];
    setImageOptions(placeholderImages);
  };

  const handleSelectImage = (imgUrl) => {
    setSentenceImages([...sentenceImages, imgUrl]);
    setImageOptions([]);
    setWord("");
  };

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">Visual Sentence Builder</h1>

      <div className="mb-4">
        <input
          type="text"
          value={word}
          onChange={(e) => setWord(e.target.value)}
          placeholder="Type a word..."
          className="p-2 border rounded mr-2"
        />
        <button
          onClick={handleSearch}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          Search
        </button>
      </div>

      <div className="mb-6">
        <h2 className="font-semibold">Your Sentence:</h2>
        <div className="flex gap-2 mt-2">
          {sentenceImages.map((img, index) => (
            <img key={index} src={img} alt="word" className="w-16 h-16" />
          ))}
        </div>
      </div>

      <div>
        <h2 className="font-semibold">Choose an image:</h2>
        <div className="flex gap-4 mt-2">
          {imageOptions.map((img, index) => (
            <img
              key={index}
              src={img}
              alt={`option ${index}`}
              className="w-24 h-24 cursor-pointer hover:ring-2 hover:ring-blue-400"
              onClick={() => handleSelectImage(img)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
